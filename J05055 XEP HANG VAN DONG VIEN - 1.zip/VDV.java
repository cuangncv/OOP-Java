import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class VDV {
    private String ten, ma, thucTe, uuTien, thanhTich, ngaySinh;
    private LocalTime xuatPhat, dich;
    private int rank;

    public VDV(int i, String ten, String ngaySinh, String xuatPhat, String dich) {
        this.ma = String.format("VDV%02d",i);
        this.ten = ten;
        this.ngaySinh = ngaySinh;
        this.xuatPhat = LocalTime.parse(xuatPhat, DateTimeFormatter.ofPattern("HH:mm:ss"));
        this.dich = LocalTime.parse(dich, DateTimeFormatter.ofPattern("HH:mm:ss"));
        setThucTe();
        setUuTien();
        setThanhTich();
    }
    private String formatDuration(Duration d) {
        long hours = d.toHours();
        long minutes = d.toMinutes() % 60;
        long seconds = d.getSeconds() % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
    private void setThucTe(){
        Duration duration = Duration.between(xuatPhat, dich);
        this.thucTe = formatDuration(duration);
    }
    private void setUuTien(){
        String year = ngaySinh.substring(6);
        int key = 2021 - Integer.parseInt(year);
        if(key < 18) this.uuTien = "00:00:00";
        else if(key < 25) this.uuTien = "00:00:01";
        else if(key < 32) this.uuTien = "00:00:02";
        else this.uuTien = "00:00:03";
    }
    private void setThanhTich(){
        LocalTime tt = LocalTime.parse(thucTe, DateTimeFormatter.ofPattern("HH:mm:ss"));
        LocalTime ut = LocalTime.parse(uuTien, DateTimeFormatter.ofPattern("HH:mm:ss"));
        Duration d = Duration.between(ut,tt);
        this.thanhTich = formatDuration(d);
    }
    public void setRank(int rank){
        this.rank = rank;
    }
    public String getThanhTich(){
        return  thanhTich;
    }
    public String getMa(){
        return ma;
    }
    @Override
    public String toString(){
        return String.format("%s %s %s %s %s %d", ma, ten, thucTe, uuTien, thanhTich, rank);
    }
}