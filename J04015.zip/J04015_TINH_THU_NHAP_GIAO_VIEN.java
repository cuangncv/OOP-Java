import java.util.Scanner;

public class J04015_TINH_THU_NHAP_GIAO_VIEN {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String MaNgach = in.nextLine();
        String HoTen = in.nextLine();
        long LuongCoBan = Long.parseLong(in.nextLine());
        GiaoVien gv = new GiaoVien (MaNgach, HoTen, LuongCoBan);
        System.out.println(gv);
        in.close();
    }
}
