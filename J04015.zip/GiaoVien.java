public class GiaoVien {
    private String MaNgach , HoTen;
    private long LuongCoBan;
    public GiaoVien (String MaNgach, String HoTen, long LuongCoBan){
        this.MaNgach = MaNgach;
        this.HoTen = HoTen;
        this.LuongCoBan = LuongCoBan;
    }
    public int getBacLuong (){
        return Integer.parseInt(this.MaNgach.substring(2));
    }
    public int getPhuCap() {
        String x = this.MaNgach.substring(0,2);
        if( x.equals("HT")) return 2000000;
        if( x.equals("HP")) return 900000;
        return 500000;
    }
    public long thuNhap (){
        return this.LuongCoBan * getBacLuong() + getPhuCap();
    }
    public String toString (){
        return this.MaNgach + " " + this.HoTen + " " + getBacLuong() + " " + getPhuCap() + " " + thuNhap();
    }
}
