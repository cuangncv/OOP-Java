public class KhachHang {
    private String ma, ten, gioiTinh, ngaySinh, diaChi;

    public KhachHang(String ma, String ten, String gioiTinh, String ngaySinh, String diaChi) {
        this.ma = ma;
        this.ten = ten;
        this.gioiTinh = gioiTinh;
        this.ngaySinh = ngaySinh;
        this.diaChi = diaChi;
    }

    public String getMa() {
        return ma;
    }

    public String toString() {
        return ten + " " + diaChi;
    }
}