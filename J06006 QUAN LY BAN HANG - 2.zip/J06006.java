import java.util.*;

public class J06006 {
    public static void main(String[] args)  {
        Scanner in = new Scanner(System.in);
        int N = Integer.parseInt(in.nextLine());
        Map<String, KhachHang> mKH = new HashMap<>();
        for(int i = 1; i <= N; i++){
            String ma = String.format("KH%03d", i);
            KhachHang kh = new KhachHang(ma, in.nextLine(), in.nextLine(), in.nextLine(), in.nextLine());
            mKH.put(ma, kh);
        }
        Map<String, MatHang> mMH = new HashMap<>();
        int M = Integer.parseInt(in.nextLine());
        for(int i = 1; i <= M; i++){
            String ma = String.format("MH%03d", i);
            MatHang mh = new MatHang(ma, in.nextLine(), in.nextLine(), Integer.parseInt(in.nextLine()), Integer.parseInt(in.nextLine()));
            mMH.put(ma, mh);
        }
        ArrayList<HoaDon> arr = new ArrayList<>();
        int K = Integer.parseInt(in.nextLine());
        for(int i = 1; i <= K; i++){
            String ma = String.format("HD%03d", i);
            String maKh = in.next();
            String maMh = in.next();
            HoaDon hd = new HoaDon(ma, mKH.get(maKh), mMH.get(maMh), in.nextInt());
            arr.add(hd);
            in.nextLine();
        }
        Collections.sort(arr);
        for(HoaDon d : arr) System.out.println(d);
        in.close();
    }
}