public class MatHang {
    private String ma, ten, donVi;
    private int giaMua, giaBan;

    public MatHang(String ma, String ten, String donVi, int giaMua, int giaBan) {
        this.ma = ma;
        this.ten = ten;
        this.donVi = donVi;
        this.giaMua = giaMua;
        this.giaBan = giaBan;
    }

    public String getMa() {
        return ma;
    }

    public int getGiaBan() {
        return giaBan;
    }

    public int getGiaMua(){
        return giaMua;
    }

    public String toString(){
        return ten ;
    }
}