public class HoaDon implements Comparable<HoaDon> {
    private String ma;
    private KhachHang kh;
    private MatHang mh;
    private int soLuong, tien, loiNhuan;

    public HoaDon(String ma, KhachHang kh, MatHang mh, int soLuong) {
        this.ma = ma;
        this.kh = kh;
        this.mh = mh;
        this.soLuong = soLuong;
        this.tien = soLuong * mh.getGiaBan();
        this.loiNhuan = soLuong * (mh.getGiaBan() - mh.getGiaMua());
    }
    public int compareTo(HoaDon other){
        return Integer.compare(other.loiNhuan, this.loiNhuan);
    }
    @Override
    public String toString(){
        return String.format("%s %s %s %d %d %d", ma, kh, mh, soLuong, tien, loiNhuan);
    }
}
