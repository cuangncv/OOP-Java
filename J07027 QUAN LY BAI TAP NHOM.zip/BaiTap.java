public class BaiTap {
    private String btl;
    private int stt;

    public BaiTap(int stt, String btl) {
        this.btl = btl;
        this.stt = stt;
    }

    public String getBtl() {
        return btl;
    }

    public int getStt() {
        return stt;
    }
    @Override
    public String toString(){
        return stt + " " + btl;
    }
}