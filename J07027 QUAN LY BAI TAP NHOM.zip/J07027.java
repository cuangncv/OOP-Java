import java.io.File;
import java.util.*;

public class J07027 {
    public static void main(String[] args) throws Exception{
        Scanner in1 = new Scanner(new File("SINHVIEN.in"));
        Scanner in2 = new Scanner(new File("BAITAP.in"));
        Scanner in3 = new Scanner(new File("NHOM.in"));
        int t1 = Integer.parseInt(in1.nextLine());
        Map<String, SinhVien> m1 = new HashMap<>();
        for(int i = 1; i <= t1; i++){
            String ma = in1.nextLine();
            SinhVien sv = new SinhVien(ma, in1.nextLine(), in1.nextLine());
            m1.put(ma, sv);
        }
        int t2 = Integer.parseInt(in2.nextLine());
        Map<Integer, BaiTap> m2 = new HashMap<>();
        for(int i = 1; i <= t2; i++){
            int stt = i;
            BaiTap bt = new BaiTap(i, in2.nextLine());
            m2.put(stt, bt);
        }
        ArrayList<Nhom> arr = new ArrayList<>();
        for(int i = 1; i <= t1; i++){
            String ma = in3.next();
            int stt = in3.nextInt();
            in3.nextLine();
            Nhom n = new Nhom(ma, m1.get(ma), m2.get(stt));
            arr.add(n);
        }
        Collections.sort(arr);
        for(Nhom n : arr){
            System.out.println(n);
        }
        in1.close();
        in2.close();
        in3.close();
    }
}