public class Nhom implements Comparable<Nhom> {
    private SinhVien sv;
    private BaiTap bt;
    private String ma;

    public Nhom(String ma, SinhVien sv, BaiTap bt) {
        this.ma = ma;
        this.sv = sv;
        this.bt = bt;
    }
    public int compareTo(Nhom other){
        return this.ma.compareTo(other.ma);
    }
    @Override
    public String toString(){
        return sv + " " + bt;
    }
}
