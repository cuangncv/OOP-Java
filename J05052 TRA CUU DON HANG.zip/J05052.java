import java.util.*;

public class J05052 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        ArrayList<DonHang> lt = new ArrayList<>();
        for(int i = 1; i<=t; i++){
            DonHang donHang = new DonHang(in.nextLine(), in.nextLine(), Long.parseLong(in.nextLine()), Long.parseLong(in.nextLine()));
            lt.add(donHang);
        }
        for(DonHang s : lt) {
            System.out.println(s);
        }
        in.close();
    }
}