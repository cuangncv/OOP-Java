public class HoaDon{
    private String ma;
    private SanPham sp;
    private long soLuong, tien, loai, gia, giamgia;

    public HoaDon(String ma, SanPham sp, long soLuong) {
        this.ma = ma;
        this.soLuong = soLuong;
        this.sp = sp;
        this.loai = Integer.parseInt(ma.substring(2,3));
        setGia();
        setGiamgia();
    }
    private void setGia(){
        if(loai == 1) this.gia = sp.getGia1();
        else this.gia = sp.getGia2();
    }
    private void setGiamgia(){
        this.tien = soLuong * gia;
        if(soLuong >= 150 ) this.giamgia = this.tien / 2;
        else if( soLuong >= 100) this.giamgia = this.tien * 3 / 10;
        else if(soLuong >= 50) this.giamgia = this.tien * 15 / 100;
        this.tien -= giamgia;
    }
    @Override
    public String toString(){
        return String.format("%s %s %d %d", ma, sp.getTen(), giamgia, tien);
    }
}
