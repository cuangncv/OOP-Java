import java.io.File;
import java.util.*;

public class J07019 {
    public static void main(String[] args) throws Exception{
        Scanner in1 = new Scanner(new File("DATA1.in"));
        int t1 = Integer.parseInt(in1.nextLine());
        Map<String,SanPham> mp1 = new HashMap<>();
        for(int i = 1; i <= t1; i++){
            String ma = in1.nextLine();
            SanPham sp = new SanPham(ma, in1.nextLine(), Long.parseLong(in1.nextLine()), Long.parseLong(in1.nextLine()));
            mp1.put(ma, sp);
        }
        Scanner in2 = new Scanner(new File("DATA2.in"));
        int t2 = Integer.parseInt(in2.nextLine());
        ArrayList<HoaDon> lt = new ArrayList<>();
        for(int i = 1; i<=t2; i++){
            String ma = in2.next();
            long sl = in2.nextInt();
            in2.nextLine();
            HoaDon hd = new HoaDon(String.format("%s-%03d", ma, i), mp1.get(ma.substring(0,2)), sl);
            lt.add(hd);
        }
        for(HoaDon h : lt) System.out.println(h);
        in1.close();
        in2.close();
    }
}