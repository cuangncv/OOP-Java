public class NhanVien implements Comparable<NhanVien> {
    private String chuc_vu,he_so_luong, so_hieu, ten;

    public NhanVien(String ma, String ten) {
        this.chuc_vu = ma.substring(0,2);
        this.he_so_luong = ma.substring(2,4);
        this.so_hieu = ma.substring(4);
        this.ten = ten;
    }

    public void setChuc_vu(String k){
        this.chuc_vu = k;
    }

    public String getChuc_vu() {
        return chuc_vu;
    }

    public int compareTo(NhanVien other) {
        if(this.he_so_luong.equals(other.he_so_luong)) return this.so_hieu.compareTo(other.so_hieu);
        else return other.he_so_luong.compareTo(this.he_so_luong);
    }

    public String toString() {
        return ten + " "  + chuc_vu + " " + so_hieu + " " + he_so_luong;
    }
}