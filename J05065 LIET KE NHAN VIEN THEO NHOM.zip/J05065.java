import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J05065 {
    public static void main(String[] args)  {
        Scanner in = new Scanner(System.in);
        ArrayList<NhanVien> lt = new ArrayList<>();
        int t = Integer.parseInt(in.nextLine());
        int dgd = 0, dtp = 0, dpp = 0;
        while (t-- >0){
            NhanVien nv = new NhanVien(in.next(), in.nextLine().trim());
            if(nv.getChuc_vu().equals("GD")){
                dgd++;
                if(dgd > 1) nv.setChuc_vu("NV");
            }
            if(nv.getChuc_vu().equals("TP")){
                dtp++;
                if(dtp > 3) nv.setChuc_vu("NV");
            }
            if(nv.getChuc_vu().equals("PP")){
                dpp++;
                if(dpp > 3) nv.setChuc_vu("NV");
            }
            lt.add(nv);
        }
        Collections.sort(lt);
        int q = Integer.parseInt(in.nextLine());
        ArrayList<String> arr = new ArrayList<>();
        while (q-- >0){
            String s = in.nextLine();
            arr.add(s);
        }
        for(String s : arr){
            for(NhanVien n : lt){
                if(s.equals(n.getChuc_vu())) System.out.println(n);
            }
            System.out.println();
        }
        in.close();
    }
}