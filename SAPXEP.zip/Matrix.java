import java.util.Arrays;

public class Matrix {
    private int n, m, y;
    private int [][] a;
    public Matrix (int n, int m, int y){
        this.n = n;
        this.m = m;
        this.y = y;
        a = new int [n][m];
    }
    public void setA (int n, int m, int value){
        a[n][m] = value;
    }
    public int getA (int n, int m){
        return a[n][m];
    }
    public void sxCoti (){
        int [] x = new int [n];
        for(int i = 0; i < n; i++){
            x[i] = a[i][y-1];
        }
        Arrays.sort(x);
        for(int i = 0; i < n; i++){
            a[i][y-1] = x[i];
        }
    }
    public String toString(){
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                sb.append(a[i][j]).append(" ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}
