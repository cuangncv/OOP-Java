import java.io.File;
import java.io.IOException;
import java.util.*;


public class Sap_xep_ma_tran  {
    public static void main(String[] args) throws IOException  {
        Scanner in = new Scanner(new File("MATRIX.in"));
        int t = in.nextInt();
        while(t-- >0){
            int n = in.nextInt();
            int m = in.nextInt();
            int y = in.nextInt();
            int [][] a = new int[n][m];
            for(int i = 0; i < n; i++){
                for(int j = 0; j < m; j++){
                    a[i][j] = in.nextInt();
                }
            }
            Matrix mt = new Matrix(n, m , y);
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    mt.setA(i, j, a[i][j]);
                }
            }
            mt.sxCoti();
            System.out.println(mt);
        }
    }
}
