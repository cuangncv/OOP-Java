import java.util.*;

public class J05047 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        ArrayList<MatHang> lt = new ArrayList<>();
        Map<String,Integer> mp = new TreeMap<>();
        for (int i = 1; i <= t; i++){
            String ten = in.nextLine();
            long soLuong = Long.parseLong(in.nextLine());
            long donGia = Long.parseLong(in.nextLine());
            String [] a = ten.trim().split("\\s+");
            String m = a[0].substring(0,1).toUpperCase() + a[1].substring(0,1).toUpperCase();
            if(mp.containsKey(m)) mp.put(m, mp.get(m) + 1);
            else mp.put(m, 1);
            String ma = String.format("%s%02d", m, mp.get(m));
            MatHang mh = new MatHang(ma, ten, soLuong, donGia);
            lt.add(mh);
        }
        Collections.sort(lt);
        for(MatHang h : lt) System.out.println(h);
        in.close();
    }
}