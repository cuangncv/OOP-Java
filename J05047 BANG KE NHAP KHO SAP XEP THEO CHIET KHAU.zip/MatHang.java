public class MatHang implements Comparable<MatHang> {
    private String ma, ten;
    private long soLuong, donGia;
    private double tien, chietKhau;

    public MatHang (String ma, String ten, long soLuong, long donGia){
        this.ma = ma;
        this.ten = ten;
        this.soLuong = soLuong;
        this.donGia = donGia;
        setChietKhau();
        this.tien = soLuong * donGia - chietKhau;
    }

    private void setChietKhau(){
        if(soLuong > 10) this.chietKhau = 0.05 * donGia * soLuong;
        else if(soLuong >= 8) this.chietKhau = 0.02 * donGia * soLuong;
        else if(soLuong >= 5) this.chietKhau = 0.01 * donGia * soLuong;
        else this.chietKhau = 0;
    }

    public int compareTo(MatHang other){
        return Double.compare(other.chietKhau, this.chietKhau);
    }
    @Override
    public String toString(){
        return String.format("%s %s %.0f %.0f", ma, ten, chietKhau, tien);
    }
}
