import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J05058 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        ArrayList<ThiSinh> lt = new ArrayList<>();
        int t = Integer.parseInt(in.nextLine());
        while (t-- >0){
            ThiSinh ts = new ThiSinh(in.nextLine(), in.nextLine(), Double.parseDouble(in.nextLine()), Double.parseDouble(in.nextLine()), Double.parseDouble(in.nextLine()));
            lt.add(ts);
        }
        Collections.sort(lt);
        for(ThiSinh s : lt){
            System.out.println(s);
        }
        in.close();
    }
}