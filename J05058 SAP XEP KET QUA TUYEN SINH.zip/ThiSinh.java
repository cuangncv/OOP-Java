public class ThiSinh implements Comparable <ThiSinh> {
    private String ma, ten, trangThai;
    private double diemUT, xetTuyen, tongdiem;

    public ThiSinh(String ma, String ten, double d1, double d2, double d3){
        this.ma = ma;
        setTen(ten);
        setDiemUuTien(ma);
        this.xetTuyen = d1 * 2 + d2 + d3 ;
        this.tongdiem = xetTuyen + diemUT;
        setTrangThai();
    }

    public double getXetTuyen() {
        return xetTuyen;
    }

    private void setTen(String ten){
        String [] a = ten.trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < a.length; i ++){
            sb.append(a[i].substring(0,1).toUpperCase()+a[i].substring(1).toLowerCase()+" ");
        }
        this.ten = sb.toString();
    }

    private void setDiemUuTien(String ma){
        String x = ma.substring(0,3);
        if(x.equals("KV1")) this.diemUT = 0.5;
        if(x.equals("KV2")) this.diemUT = 1;
        if(x.equals("KV3")) this.diemUT = 2.5;
    }

    private void setTrangThai(){
        if(tongdiem >= 24) this.trangThai = "TRUNG TUYEN";
        else this.trangThai = "TRUOT";
    }
    private String formatNumber(double number) {
        if (number == (int) number) {
            return String.format("%d", (int) number); // In dưới dạng int nếu là số nguyên
        }
        return String.format("%.1f", number); // In dưới dạng 1 chữ số thập phân nếu không phải số nguyên
    }
    public int compareTo(ThiSinh other){
        if(this.tongdiem == other.tongdiem){
            return this.ma.compareTo(other.ma);
        }
        return Double.compare(other.tongdiem, this.tongdiem);
    }
    @Override
    public String toString(){
        return ma + " " + ten + formatNumber(diemUT) + " " + formatNumber(tongdiem) + " " + trangThai;
    }
}