import java.util.*;
public class J05056 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        ArrayList<VDV> lt = new ArrayList<>();
        for(int i = 1; i<=t; i++){
            VDV v = new VDV(i, in.nextLine(), in.nextLine(), in.nextLine(), in.nextLine());
            lt.add(v);
        }
        Collections.sort(lt, new Comparator<VDV>() {
            @Override
            public int compare(VDV o1, VDV o2) {
                return o1.getThanhTich().compareTo(o2.getThanhTich());
            }
        });
        int rank = 1;
        for(int i = 0; i < lt.size(); i++){
            if(i > 0 && !lt.get(i).getThanhTich().equals(lt.get(i-1).getThanhTich())){
                rank = i + 1;
            }
            lt.get(i).setRank(rank);
        }
        for(VDV q : lt) System.out.println(q);
        in.close();
    }
}