import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class TINH_DIEM_TRUNG_BINH {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        ArrayList<Double> ds = new ArrayList<>();
        int N = in.nextInt();
        for (int i = 0; i < N; i++) {
            double x = in.nextDouble();
            ds.add(x);
        }
        DIEM d = new DIEM(ds);
        System.out.println(d);
    }
}