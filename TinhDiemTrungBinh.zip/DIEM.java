import java.util.ArrayList;
import java.util.Collections;

public class DIEM {
    private ArrayList<Double> ds;
    private double tong;

    public DIEM (ArrayList<Double> ds){
        this.ds = ds;
        Collections.sort(ds);
        tong = 0;
    }

    public Double diemTB(){
        double nho = ds.get(0);
        double lon = ds.get(ds.size() -1);
        double dem = 0;
        for(double q : ds){
            if(q != nho && q != lon){
                tong += q;
                dem ++;
            }
        }
        return tong/dem;
    }

    @Override
    public String toString(){
        return String.format("%.2f",diemTB());
    }
}