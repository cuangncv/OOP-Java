import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J05012 {
    public static void main(String[] args)  {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        ArrayList<HoaDon> lt = new ArrayList<>();
        for(int i = 1; i <= t; i++){
            HoaDon ct = new HoaDon( in.nextLine(), in.nextLine(), Long.parseLong(in.nextLine()), Long.parseLong(in.nextLine()), Long.parseLong(in.nextLine()));
            lt.add(ct);
        }
        Collections.sort(lt);
        for(HoaDon c : lt) System.out.println(c);
        in.close();
    }
}
