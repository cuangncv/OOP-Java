import java.util.ArrayList;
import java.util.Scanner;

public class J05044 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        ArrayList<NhanVien> lt = new ArrayList<>();
        for (int i = 1; i <= t; i++){
            NhanVien nv = new NhanVien(i, in.nextLine(), in.nextLine(), Long.parseLong(in.nextLine()), Long.parseLong(in.nextLine()));
            lt.add(nv);
        }
        String q = in.nextLine();
        for(NhanVien x : lt){
            if(x.getChucVu().equals(q)) {
                System.out.println(x);
            }
        }
        in.close();
    }
}