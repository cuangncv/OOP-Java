public class KhachHang implements Comparable<KhachHang>{
    private String ma, loai;
    private int heSo, csMoi, csCu;
    private long thanhTien, phuTroi, tongTien;

    public KhachHang (int i, String loaiSD, int csCu, int csMoi){
        this.ma = String.format("KH%02d", i);
        this.loai = loaiSD;
        this.csCu = csCu;
        this.csMoi = csMoi;
    }
    public void setHeSo(){
        if(loai.equals("KD")) this.heSo = 3;
        if(loai.equals("NN")) this.heSo = 5;
        if(loai.equals("TT")) this.heSo = 4;
        if(loai.equals("CN")) this.heSo = 2;
    }
    public void setThanhTien(){
        this.thanhTien = (csMoi - csCu) * heSo * 550;
    }
    public void setPhuTroi(){
        if((csMoi - csCu) < 50) this.phuTroi = 0;
        else if((csMoi - csCu) <= 100) this.phuTroi = Math.round(thanhTien * 35 / 100.0);
        else this.phuTroi = thanhTien;
    }
    public void setTongTien(){
        this.tongTien = thanhTien + phuTroi;
    }
    public int compareTo(KhachHang other){
        return Long.compare(other.tongTien, this.tongTien);
    }

    @Override
    public String toString(){
        return ma + " " + heSo + " " + thanhTien + " " + phuTroi + " " + tongTien;
    }
}