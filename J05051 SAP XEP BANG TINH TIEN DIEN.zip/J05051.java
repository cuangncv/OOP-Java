import java.util.*;

public class J05051 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        ArrayList<KhachHang> lt = new ArrayList<>();
        for(int i = 1; i<=t; i++){
           KhachHang kh = new KhachHang(i, in.nextLine(), Integer.parseInt(in.nextLine()), Integer.parseInt(in.nextLine()));
           kh.setHeSo();
           kh.setThanhTien();
           kh.setPhuTroi();
           kh.setTongTien();
           lt.add(kh);
        }
        Collections.sort(lt);
        for(KhachHang s : lt) {
            System.out.println(s);
        }
        in.close();
    }
}