import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J05066 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        ArrayList<NhanVien> ds = new ArrayList<>();

        int n = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < n; i++) {
            String ma = sc.next();
            String ten = sc.nextLine().trim();

            String chuc_vu = ma.substring(0, 2);
            String he_so_luong = ma.substring(2, 4);
            String so_hieu = ma.substring(4);

            if (chuc_vu.equals("GD")) {
                int so = Integer.parseInt(so_hieu);
                if (so > 1) chuc_vu = "NV";
            } else if (chuc_vu.equals("TP")) {
                int so = Integer.parseInt(so_hieu);
                if (so > 3) chuc_vu = "NV";
            } else if (chuc_vu.equals("PP")) {
                int so = Integer.parseInt(so_hieu);
                if (so > 3) chuc_vu = "NV";
            }

            NhanVien nv = new NhanVien(chuc_vu, he_so_luong, so_hieu, ten);
            ds.add(nv);
        }

        Collections.sort(ds);

        int m = Integer.parseInt(sc.nextLine());
        ArrayList<String> lt = new ArrayList<>();
        while (m-- > 0) {
            String s = sc.nextLine().trim().toLowerCase();
            lt.add(s);
        }
        for (String s : lt) {
            for (NhanVien nv : ds) {
                if (nv.getTen().toLowerCase().contains(s)) {
                    System.out.println(nv);
                }
            }
            System.out.println();
        }
        sc.close();
    }
}
