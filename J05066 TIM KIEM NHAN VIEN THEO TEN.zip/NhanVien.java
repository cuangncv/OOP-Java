public class NhanVien implements Comparable<NhanVien> {
    private String chuc_vu, he_so_luong, so_hieu, ten;

    public NhanVien(String chuc_vu, String he_so_luong, String so_hieu, String ten) {
        this.chuc_vu = chuc_vu;
        this.he_so_luong = he_so_luong;
        this.so_hieu = so_hieu;
        this.ten = ten;
    }

    public String getTen() {
        return ten;
    }

    public int compareTo(NhanVien other) {
        if(this.he_so_luong.equals(other.he_so_luong)) return this.so_hieu.compareTo(other.so_hieu);
        else return other.he_so_luong.compareTo(this.he_so_luong);
    }

    public String toString() {
        return ten + " "  + chuc_vu + " " + so_hieu + " " + he_so_luong;
    }
}