import java.util.ArrayList;
import java.util.Scanner;

public class J05064 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int dem_ht = 0, dem_hp = 0;
        ArrayList<GiaoVien> lt = new ArrayList<>();

        int n = Integer.parseInt(in.nextLine());
        for(int i = 0; i < n; i++) {
            String maGV = in.nextLine();
            String tenGV = in.nextLine();
            long luong_co_ban = Long.parseLong(in.nextLine());

            GiaoVien gv = new GiaoVien(maGV, tenGV, luong_co_ban);

            if(gv.getChucVu().equals("HT")) {
                if(dem_ht < 1) {
                    ++dem_ht;
                    lt.add(gv);
                }
            } else if(gv.getChucVu().equals("HP")) {
                if(dem_hp < 2) {
                    ++dem_hp;
                    lt.add(gv);
                }
            } else {
                lt.add(gv);
            }
        }
        for(GiaoVien g : lt){
            System.out.println(g);
        }
        in.close();
    }
}
