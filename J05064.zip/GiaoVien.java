public class GiaoVien {
    private String maGV, tenGV;
    private long luong_co_ban;

    private String chuc_vu;
    private int he_so;
    private long phu_cap, thu_nhap;

    public GiaoVien(String maGV, String tenGV, long luong_co_ban) {
        this.maGV = maGV;
        this.tenGV = tenGV;
        this.luong_co_ban = luong_co_ban;
        this.chuc_vu =  maGV.substring(0, 2);
        this.he_so = Integer.parseInt(maGV.substring(2));
        setPhuCap();
        this.thu_nhap = luong_co_ban * he_so + phu_cap;
    }

    public String getChucVu() {
        return chuc_vu;
    }

    public void setPhuCap() {
        if(chuc_vu.equals("HT")) {
            phu_cap = 2000000;
        } else if(chuc_vu.equals("HP")) {
            phu_cap = 900000;
        } else {
            phu_cap = 500000;
        }
    }

@Override
    public String toString() {
        return maGV + " " + tenGV + " " + he_so + " " + phu_cap + " " + thu_nhap;
    }
}