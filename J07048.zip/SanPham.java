public class SanPham implements Comparable<SanPham> {
    private String ma, ten;
    private int giaban, thoihan;
    public SanPham (String ma, String ten, int giaban, int thoihan){
       this.ma = ma;
       this.ten = ten;
       this.giaban = giaban;
       this.thoihan = thoihan;
    }

    @Override
    public String toString(){
        return ma + " " + ten + " " + giaban + " " + thoihan;
    }

    @Override
    public int compareTo(SanPham other){
        if(this.giaban == other.giaban){
            return this.ma.compareTo(other.ma);
        }
        return Integer.compare(other.giaban, this.giaban);
    }
}
