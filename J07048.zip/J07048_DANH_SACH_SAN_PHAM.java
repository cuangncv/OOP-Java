import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J07048_DANH_SACH_SAN_PHAM {
    public static void main(String[] args) throws IOException  {
        ArrayList<SanPham> ds = new ArrayList<>();
        Scanner in = new Scanner(new File("SANPHAM.in"));
        int n = Integer.parseInt(in.nextLine());
        while(n-->0){
            ds.add(new SanPham(in.nextLine(), in.nextLine(), Integer.parseInt(in.nextLine()), Integer.parseInt(in.nextLine())));
        }
        Collections.sort(ds);
        for(SanPham tmp : ds){
            System.out.println(tmp);
        }
        in.close();
    }
}
