public class NhanVien implements Comparable <NhanVien> {
    private String ma, ten, chucVu;
    private long luongThang, phuCap, tamUng, conLai, thuNhap;

    public NhanVien (int i, String ten, String chucVu, long luongCB, long soNgay){
        this.ma = String.format("NV%02d",i);
        this.ten = ten;
        this.chucVu = chucVu;
        setPhuCap();
        this.luongThang = luongCB * soNgay ;
        this.thuNhap = (luongThang + phuCap) * 2 / 3;
        setTamUng();
        this.conLai = luongThang + phuCap - tamUng;
    }

    private void setPhuCap(){
        if(chucVu.equals("GD")) this.phuCap = 500;
        else if(chucVu.equals("PGD")) this.phuCap = 400;
        else if(chucVu.equals("TP")) this.phuCap = 300;
        else if(chucVu.equals("KT")) this.phuCap = 250;
        else this.phuCap = 100;
    }

    private void setTamUng(){
        if( thuNhap < 25000) this.tamUng = Math.round(thuNhap / 1000.0) * 1000;
        else this.tamUng = 25000;
    }

    public int compareTo(NhanVien other){
        if(this.thuNhap == other.thuNhap){
           return this.ma.compareTo(other.ma);
        }
        return Long.compare(other.thuNhap, this.thuNhap);
    }

    @Override
    public String toString(){
        return String.format("%s %s %d %d %d %d", ma, ten, phuCap, luongThang, tamUng, conLai);
    }
}