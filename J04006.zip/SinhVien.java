public class SinhVien {
    private String name, className, date;
    private float gpa;

    public SinhVien(String name, String className, String date, float gpa) {
        this.name = name;
        this.className = className;
        this.date = date;
        this.gpa = gpa;
    }
    public void setDate() {
        String[] arr = date.split("/");
        if (arr[0].length() == 1) arr[0] = "0" + arr[0];
        if (arr[1].length() == 1) arr[1] = "0" + arr[1];
        date = arr[0] + "/" + arr[1] + "/" + arr[2];
    }
    public String toString() {
        return "B20DCCN001 " + name + " " + className + " " + date + " " + String.format("%.2f", gpa);
    }
}