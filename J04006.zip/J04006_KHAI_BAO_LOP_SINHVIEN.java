import java.util.Scanner;

public class J04006_KHAI_BAO_LOP_SINHVIEN {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        String className = sc.nextLine();
        String date = sc.nextLine();
        float gpa = sc.nextFloat();
        SinhVien sv = new SinhVien(name, className, date, gpa);
        sv.setDate();
        System.out.println(sv);
        sc.close();
    }
}
