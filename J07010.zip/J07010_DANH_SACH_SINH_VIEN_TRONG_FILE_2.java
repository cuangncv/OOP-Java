import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class J07010_DANH_SACH_SINH_VIEN_TRONG_FILE_2 {
    public static void main(String[] args) throws IOException {
        Scanner in = new Scanner(new File("SV.in"));
        int n = in.nextInt();
        for(int i = 1; i <= n; i++){
            in.nextLine();
            SinhVien sv = new SinhVien(i, in.nextLine(), in.nextLine(), in.nextLine(), in.nextDouble());
            sv.setNgaySinh();
            System.out.println(sv);
        }
        in.close();
    }
}
