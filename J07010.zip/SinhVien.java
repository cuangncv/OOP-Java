public class SinhVien {
    private String msv, HoTen, Lop, NgaySinh;
    private double gpa;
    public SinhVien (int i, String HoTen, String Lop, String NgaySinh, double gpa){
        this.msv = "B20DCCN" + String.format("%03d",i);
        this.HoTen = HoTen;
        this.Lop = Lop;
        this.NgaySinh = NgaySinh;
        this.gpa = gpa;
    }
    public void setNgaySinh(){
        String [] a = NgaySinh.split("/");
        if(a[0].length() == 1) a[0] = "0" + a[0];
        if(a[1].length() == 1) a[1] = "0" + a[1];
        NgaySinh = a[0] + "/" + a[1] + "/" + a[2];
    }
    @Override
    public String toString() {
        return String.format("%s %s %s %s %.2f", this.msv, this.HoTen, this.Lop, this.NgaySinh, this.gpa);
    }
}
