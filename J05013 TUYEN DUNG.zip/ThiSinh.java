public class ThiSinh implements Comparable<ThiSinh> {
    private String ma, ten, xepLoai;
    private double trungBinh;

    public ThiSinh(int i, String ten, double lyThuyet, double thucHanh) {
        this.ma = String.format("TS%02d", i);
        this.ten = ten;
        setTrungBinh(lyThuyet, thucHanh);
        setXepLoai();
    }

    private void setTrungBinh(double lyThuyet, double thucHanh){
        if(lyThuyet > 10) lyThuyet /= 10;
        if(thucHanh > 10) thucHanh /= 10;
        this.trungBinh = (lyThuyet + thucHanh) /2;
    }

    private void setXepLoai(){
        if(trungBinh < 5) this.xepLoai = "TRUOT";
        else if( trungBinh < 8) this.xepLoai = "CAN NHAC";
        else if(trungBinh < 9.5) this.xepLoai = "DAT";
        else this.xepLoai = "XUAT SAC";
    }

    public int compareTo(ThiSinh other){
        return Double.compare(other.trungBinh, this.trungBinh);
    }
    @Override
    public String toString(){
        return String.format("%s %s %.02f %s", ma , ten, trungBinh, xepLoai);
    }
}
