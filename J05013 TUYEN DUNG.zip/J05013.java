import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J05013 {
    public static void main(String[] args)  {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        ArrayList<ThiSinh> lt = new ArrayList<>();
        for(int i = 1; i <= t; i++){
            ThiSinh ct = new ThiSinh( i, in.nextLine(), Double.parseDouble(in.nextLine()), Double.parseDouble(in.nextLine()));
            lt.add(ct);
        }
        Collections.sort(lt);
        for(ThiSinh c : lt) System.out.println(c);
        in.close();
    }
}
