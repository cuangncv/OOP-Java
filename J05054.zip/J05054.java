import java.util.*;
public class J05054 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        ArrayList<HocSinh> lt = new ArrayList<>();
        for(int i = 1; i<=t; i++){
            HocSinh hs = new HocSinh(i, in.nextLine(), Double.parseDouble(in.nextLine()));
            lt.add(hs);
        }
        ArrayList<HocSinh> arr = new ArrayList<>(lt);
        Collections.sort(arr);
        int rank = 1;
        for(int i = 0; i < arr.size(); i++){
            if(i > 0 && arr.get(i).getDtb() != arr.get(i-1).getDtb()){
                rank = i + 1;
            }
            arr.get(i).setRank(rank);
        }
        for(HocSinh x : lt){
            for(HocSinh z : arr){
                if(x.getMa().equals(z.getMa())){
                    x.setRank(z.getRank());
                    break;
                }
            }
        }
        for(HocSinh q: lt) System.out.println(q);
        in.close();
    }
}