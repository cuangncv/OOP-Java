public class DoanhNghiep implements Comparable<DoanhNghiep> {
    private String ma, ten;
    private int sosinhvien;
    public DoanhNghiep (String ma, String ten, int sosinhvien){
        this.ma = ma;
        this.ten = ten;
        this.sosinhvien = sosinhvien;
    }

    @Override
    public String toString(){
        return ma + " " + ten + " " + sosinhvien;
    }

    @Override
    public int compareTo(DoanhNghiep other){
        return this.ma.compareTo(other.ma);
    }
}
