import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J07037_DANH_SACH_DOANH_NGHIEP {
    public static void main(String[] args) throws IOException {
        Scanner in = new Scanner(new File("DN.in"));
        int t = in.nextInt();
        ArrayList<DoanhNghiep> lt = new ArrayList<>();
        in.nextLine();
        while(t-- >0){
            DoanhNghiep dn = new DoanhNghiep (in.nextLine(), in.nextLine(), Integer.parseInt(in.nextLine()));
            lt.add(dn);
        }
        Collections.sort(lt);
        for(DoanhNghiep x : lt){
            System.out.println(x);
        }
        in.close();
    }
}
