import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J05059 {
    public static void main(String[] args)  {
        Scanner in = new Scanner(System.in);
        ArrayList<ThiSinh> lt = new ArrayList<>();
        int t = Integer.parseInt(in.nextLine());
        while (t-- >0){
            ThiSinh ts = new ThiSinh(in.nextLine(), in.nextLine(), Double.parseDouble(in.nextLine()), Double.parseDouble(in.nextLine()), Double.parseDouble(in.nextLine()));
            lt.add(ts);
        }
        Collections.sort(lt);
        int q = Integer.parseInt(in.nextLine());
        double p = lt.get(q - 1).getXetTuyen();
        System.out.println(String.format("%.1f", p));
        for(ThiSinh s : lt){
            if( s.getXetTuyen() >= p){
                System.out.println(s + "TRUNG TUYEN");
            }
            else System.out.println(s + "TRUOT");
        }
    }
}