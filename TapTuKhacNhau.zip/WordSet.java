import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;

public class WordSet {
    private String s;

    public WordSet (String s){
        this.s = s;
    }
    public List<String> toList(){
        String [] q = s.toLowerCase().trim().split("\\s+");
        List<String> lt = Arrays.asList(q);
        return lt;
    }

    public String union (WordSet other){
        List <String> lt1 = this.toList();
        List <String> lt2 = other.toList();
        TreeSet<String> uni = new TreeSet<>(lt1);
        uni.addAll(lt2);
        StringBuilder sb = new StringBuilder();
        for(String x : uni) sb.append(x+" ");
        return sb.toString();
    }

    public String intersection (WordSet other){
        List <String> lt1 = this.toList();
        List <String> lt2 = other.toList();
        TreeSet<String> inter = new TreeSet<>(lt1);
        inter.retainAll(lt2);
        StringBuilder sb = new StringBuilder();
        for(String x : inter) sb.append(x+" ");
        return sb.toString();
    }
}
