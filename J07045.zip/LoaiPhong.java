public class LoaiPhong implements Comparable<LoaiPhong> {
    private String kyhieu, ten;
    private int dongia;
    private double phiphucvu;
    public LoaiPhong (String phong){
        String [] a = phong.trim().split("\\s+");
        this.kyhieu = a[0];
        this.ten = a[1];
        this.dongia = Integer.parseInt(a[2]);
        this.phiphucvu = Double.parseDouble(a[3]);
    }

    @Override
    public String toString(){
        return kyhieu + " " + ten + " " + dongia + " " + phiphucvu;
    }

    @Override
    public int compareTo(LoaiPhong other){
        return this.ten.compareTo(other.ten);
    }
}
