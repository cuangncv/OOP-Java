public class NhanVien {
    private String name, date, sex, address, mst, KyHopDong;
    private String mnv;
    public NhanVien (String name, String sex, String date, String address, String mst, String KyHopDong){
        this.name = name;
        this.sex = sex;
        this.date = date;
        this.address = address;
        this.mst = mst;
        this.KyHopDong = KyHopDong;
        mnv = "00001";
    }
    public String toString (){
        return this.mnv + " " + this.name + " " + this.sex + " " + this.date + " " + this.address + " " + this.mst + " " + this.KyHopDong;
    }
}
