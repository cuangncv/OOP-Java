import java.util.*;
public class J04007_KHAI_BAO_LOP_NHAN_VIEN {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String name = in.nextLine();
        String sex = in.nextLine();
        String date = in.nextLine();
        String address = in.nextLine();
        String mst = in.nextLine();
        String KyHopDong = in.nextLine();
        NhanVien nv = new NhanVien (name, sex, date, address, mst, KyHopDong);
        System.out.println(nv);
        in.close();
    }
}
