import java.util.ArrayList;
import java.util.Scanner;

public class J05040_LAP_BANG_TINH_CONG {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        ArrayList<NhanVien> lt = new ArrayList<>();
        for (int i = 1; i <= t; i++){
            NhanVien nv = new NhanVien(i, in.nextLine(), Long.parseLong(in.nextLine()), Long.parseLong(in.nextLine()), in.nextLine());
            lt.add(nv);
        }
        for(NhanVien x : lt){
            System.out.println(x);
        }
        in.close();
    }
}
