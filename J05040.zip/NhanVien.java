public class NhanVien {
    private String ma, ten;
    private long luongThang, thuong, phuCap, thucLinh;

    public NhanVien (int i, String ten, long luongNgay, long soNgay, String chucVu){
        this.ma = String.format("NV%02d",i);
        this.ten = ten;
        this.luongThang = luongNgay * soNgay;
        setThuong(soNgay);
        setPhuCap(chucVu);
        this.thucLinh = luongThang + phuCap + thuong;
    }
    private void setThuong(long soNgay){
        if(soNgay >= 25) this.thuong = luongThang * 2 / 10;
        else if(soNgay >= 22) this.thuong = luongThang / 10;
        else this.thuong = 0;
    }
    private void setPhuCap(String chucVu){
        if(chucVu.equals("GD")) this.phuCap = 250000;
        if(chucVu.equals("PGD")) this.phuCap = 200000;
        if(chucVu.equals("TP")) this.phuCap = 180000;
        if(chucVu.equals("NV")) this.phuCap = 150000;
    }

    @Override
    public String toString(){
        return String.format("%s %s %d %d %d %d", ma, ten, luongThang, thuong, phuCap, thucLinh);
    }
}
