
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class CaThi implements Comparable<CaThi> {
    private String ma , phong;
    private LocalDate ngay;
    private LocalTime gio;

    public CaThi(int i, String ngay, String gio, String phong) {
        this.ma = String.format("C%03d", i);
        this.ngay = LocalDate.parse(ngay, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        this.gio = LocalTime.parse(gio, DateTimeFormatter.ofPattern("HH:mm"));
        this.phong = phong;
    }

    @Override
    public int compareTo(CaThi other) {
        if(this.ngay.equals(other.ngay)){
            if(this.gio.equals(other.gio)) return this.ma.compareTo(other.ma);
            return this.gio.isBefore(other.gio) ? -1 : 1;
        }
        return this.ngay.isBefore(other.ngay) ? -1: 1;
    }
    @Override
    public String toString(){
        return ma + " " + ngay.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " " + gio.format(DateTimeFormatter.ofPattern("HH:mm")) + " " + phong;
    }
}
