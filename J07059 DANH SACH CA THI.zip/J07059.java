import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J07059 {
    public static void main(String[] args) throws Exception{
        Scanner in = new Scanner(new File("CATHI.in"));
        int t = Integer.parseInt(in.nextLine());
        ArrayList<CaThi> lt = new ArrayList<>();
        for(int i = 1; i <= t; i++){
            CaThi ct = new CaThi(i, in.nextLine(), in.nextLine(), in.nextLine());
            lt.add(ct);
        }
        Collections.sort(lt);
        for(CaThi c : lt) System.out.println(c);
        in.close();
    }
}
