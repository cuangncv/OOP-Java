public class ThoiGian implements Comparable<ThoiGian>{
    private int gio, phut, giay;
    public ThoiGian (int gio, int phut, int giay){
        this.gio = gio;
        this.phut = phut;
        this.giay = giay;
    }
    @Override
    public String toString(){
        return gio + " " + phut + " " + giay;
    }
    @Override
    public int compareTo (ThoiGian other){
        if(this.gio == other.gio){
            if(this.phut == other.phut){
                return Integer.compare(this.giay, other.giay);
            }
            return Integer.compare(this.phut, other.phut);
        }
        return Integer.compare(this.gio, other.gio);
    }
}
