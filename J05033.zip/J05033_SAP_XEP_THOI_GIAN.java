import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J05033_SAP_XEP_THOI_GIAN {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = in.nextInt();
        ArrayList<ThoiGian> al = new ArrayList<>();
        while (t-- >0){
            al.add(new ThoiGian (in.nextInt(), in.nextInt(), in.nextInt()));
        }
        Collections.sort(al);
        for(ThoiGian i : al){
            System.out.println(i);
        }
        in.close();
    }
}
