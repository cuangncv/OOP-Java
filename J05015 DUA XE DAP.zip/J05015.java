import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J05015 {
    public static void main(String[] args)  {
        Scanner sc = new Scanner(System.in);

        ArrayList<CuaRo> dsCR = new ArrayList<>();

        int n = Integer.parseInt(sc.nextLine());
        for(int i = 0; i < n; i++) {
            String ten = sc.nextLine();
            String dvi = sc.nextLine();
            String ve_dich = sc.nextLine();

            CuaRo cr = new CuaRo(ten, dvi, ve_dich);
            cr.setMa();
            cr.setTocDo();
            dsCR.add(cr);
        }

        Collections.sort(dsCR);

        for(CuaRo cr : dsCR) {
            System.out.println(cr);
        }

        sc.close();
    }
}
