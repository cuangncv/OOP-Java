import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class CuaRo implements Comparable<CuaRo> {
    private String ten, dvi;
    private LocalTime ve_dich;
    private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("H:mm");

    private String ma;
    private long toc_do;

    public CuaRo(String ten, String dvi, String ve_dich) {
        this.ten = ten;
        this.dvi = dvi;
        this.ve_dich = LocalTime.parse(ve_dich, dtf);
    }

    public void setMa() {
        ma = "";
        String[] words = (dvi + " " + ten).trim().split("\\s+");
        for(String word : words) {
            ma += word.charAt(0);
        }
    }

    public void setTocDo() {
        LocalTime bat_dau = LocalTime.parse("6:00", dtf);
        double minutes = ChronoUnit.MINUTES.between(bat_dau, ve_dich);
        toc_do = Math.round((120.0 * 60.0) / minutes);
    }

    public int compareTo(CuaRo other) {
        return this.ve_dich.compareTo(other.ve_dich);
    }

    public String toString() {
        return ma + " " + ten + " " + dvi + " " + toc_do + " Km/h";
    }
}