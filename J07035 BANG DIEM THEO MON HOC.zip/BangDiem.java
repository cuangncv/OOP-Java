public class BangDiem implements Comparable<BangDiem> {
    private SinhVien sv;
    private MonHoc mh;
    private String diem;
    private String maSV, maMH;

    public BangDiem(SinhVien sv, MonHoc mh, String diem) {
        this.sv = sv;
        this.mh = mh;
        this.maSV = sv.getMa();
        this.maMH = mh.getMa();
        this.diem = diem;
    }
    public String getMaMH(){
        return maMH;
    }

    public int compareTo(BangDiem other){
        if(Double.parseDouble(this.diem) == Double.parseDouble(other.diem)) return this.maSV.compareTo(other.maSV);
        return Double.compare(Double.parseDouble(other.diem), Double.parseDouble(this.diem));
    }
    @Override
    public String toString(){
        return sv + " " + diem;
    }
}
