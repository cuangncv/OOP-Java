import java.util.*;

public class J05054 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        ArrayList<HocSinh> lt = new ArrayList<>();
        for(int i = 1; i<=t; i++){
            HocSinh hs = new HocSinh(i, in.nextLine(), Double.parseDouble(in.nextLine()));
            lt.add(hs);
        }
        Collections.sort(lt, new Comparator<HocSinh>() {
            @Override
            public int compare(HocSinh o1, HocSinh o2) {
                return Double.compare(o2.getDtb(), o1.getDtb());
            }
        });
        int rank = 1;
        for(int i = 0; i < lt.size(); i++){
            if(i > 0 && lt.get(i).getDtb() != lt.get(i-1).getDtb()){
                rank = i + 1;
            }
            lt.get(i).setRank(rank);
        }
        Collections.sort(lt, new Comparator<HocSinh>() {
            public int compare(HocSinh o1, HocSinh o2) {
                return o1.getMa().compareTo(o2.getMa());
            }
        });
        for(HocSinh q: lt) System.out.println(q);
        in.close();
    }
}