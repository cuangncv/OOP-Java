public class HocSinh {
    private String ten, ma, xepLoai;
    private double dtb;
    private int rank;

    public HocSinh (int i, String ten, double diem){
        this.ma = String.format("HS%02d",i);
        this.ten = ten;
        this.dtb = diem;
        setXepLoai();
    }
    private void setXepLoai(){
        if(dtb < 5) this.xepLoai = "Yeu";
        else if(dtb < 7) this.xepLoai = "Trung Binh";
        else if(dtb < 9) this.xepLoai = "Kha";
        else  this.xepLoai = "Gioi";
    }
    public void setRank(int rank){
        this.rank = rank;
    }
    public int getRank(){
        return rank;
    }
    public double getDtb (){
        return dtb;
    }
    public String getMa(){
        return ma;
    }

    @Override
    public String toString(){
        return String.format("%s %s %.1f %s %d", ma, ten, dtb, xepLoai, rank);
    }
}