import java.util.*;

public class J05048 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = Integer.parseInt(in.nextLine());
        ArrayList<SanPham> lt = new ArrayList<>();
        while(t-- >0){
            SanPham sp = new SanPham(in.nextLine(), Double.parseDouble(in.nextLine()));
            sp.setSlXuat();
            sp.setDonGia();
            sp.setTien();
            sp.setThue();
            lt.add(sp);
        }
        String q = in.nextLine();
        Collections.sort(lt);
        for(SanPham s : lt) {
            if(s.getMa().equals(q)) System.out.println(s);
        }
        in.close();
    }
}