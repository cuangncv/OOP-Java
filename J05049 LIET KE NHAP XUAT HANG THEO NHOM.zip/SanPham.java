public class SanPham implements Comparable <SanPham>{
    private String ma;
    private double slNhap, slXuat, donGia, tien, thue;

    public SanPham (String ma, double slNhap){
        this.ma = ma;
        this.slNhap = slNhap;
    }
    public void setSlXuat(){
        if(ma.substring(0,1).equals("A")) this.slXuat = slNhap * 0.6;
        else this.slXuat = slNhap * 0.7;
        this.slXuat = Math.round(this.slXuat);
    }
    public void setDonGia(){
        if(ma.substring(4).equals("Y")) this.donGia = 110000;
        else this.donGia = 135000;
    }
    public void setTien(){
        this.tien = slXuat * donGia;
    }
    public void setThue(){
        String x = ma.substring(0,1);
        String y = ma.substring(4);
        if(x.equals("A") && y.equals("Y")) this.thue = tien * 0.08;
        if(x.equals("A") && y.equals("N")) this.thue = tien * 0.11;
        if(x.equals("B") && y.equals("Y")) this.thue = tien * 0.17;
        if(x.equals("B") && y.equals("N")) this.thue = tien * 0.22;
    }
    public String getMa(){
        return ma.substring(0,1);
    }

    public int compareTo(SanPham other){
        return Double.compare(other.thue, this.thue);
    }
    @Override
    public String toString(){
        return String.format("%s %.0f %.0f %.0f %.0f %.0f", ma, slNhap, slXuat, donGia, tien, thue);
    }
}
