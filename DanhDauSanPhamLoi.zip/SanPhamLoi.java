import java.util.ArrayList;

public class SanPhamLoi {
    private int n ,m;
    private int [] a;

    public SanPhamLoi (int n, int m, int [] a){
        this.n = n;
        this.m = m;
        this.a = a;
    }

    public String dung (){
        int i = 1;
        ArrayList<String> lt1 = new ArrayList<>();
        while(i <= n){
            int k = i;
            if(a[i] == 0){
                StringBuilder sb = new StringBuilder();
                sb.append(i);
                while(i<n && a[i+1] == 0 ){
                    i++;
                }
                if(i!=k) sb.append("-"+i);
                lt1.add(sb.toString());
                i++;
            }
            else {
                i++;
            }
        }
        StringBuilder b = new StringBuilder();
        b.append("Correct: "+ lt1.get(0));
        for(int j = 1; j <lt1.size()-1; j++){
            b.append(", "+lt1.get(j));
        }
        b.append(" and "+ lt1.get(lt1.size()-1));
        return b.toString();
    }
    public String sai (){
        int i = 1;
        ArrayList<String> lt2 = new ArrayList<>();
        while(i <= n){
            int k = i;
            if(a[i] != 0){
                StringBuilder sb = new StringBuilder();
                sb.append(i);
                while(i<n && a[i+1] != 0 ){
                    i++;
                }
                if(i!=k) sb.append("-"+i);
                lt2.add(sb.toString());
                i++;
            }
            else {
                i++;
            }
        }
        StringBuilder b = new StringBuilder();
        b.append("Errors: "+ lt2.get(0));
        for(int j = 1; j < lt2.size()-1; j++){
            b.append(", "+ lt2.get(j));
        }
        b.append(" and "+ lt2.get(lt2.size()-1));
        return b.toString();
    }
}
