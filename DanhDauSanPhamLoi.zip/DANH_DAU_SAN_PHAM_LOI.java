
import java.util.Scanner;

public class DANH_DAU_SAN_PHAM_LOI {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        int [] a = new int [n+1];
        for(int i = 1; i <= m; i++){
            int x = in.nextInt();
            a[x]++;
        }
        SanPhamLoi x = new SanPhamLoi(n,m,a);
        System.out.println(x.sai());
        System.out.println(x.dung());
    }
}
