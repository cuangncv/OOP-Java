public class MonHoc implements Comparable<MonHoc> {
    private String ma, ten;
    private int sotinchi;
    public MonHoc (String ma, String ten, int sotinchi){
        this.ma = ma;
        this.ten = ten;
        this.sotinchi = sotinchi;
    }
    public String getMa() {
        return ma;
    }
    public String getTen() {
        return ten;
    }
    public int getSotinchi() {
        return sotinchi;
    }
    @Override
    public String toString(){
        return ma + " " + ten + " " + sotinchi;
    }

    @Override
    public int compareTo(MonHoc other){
        return this.ten.compareTo(other.ten);
    }
}
