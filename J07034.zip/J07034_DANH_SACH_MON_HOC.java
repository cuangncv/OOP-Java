import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class J07034_DANH_SACH_MON_HOC  {
    public static void main(String[] args) throws IOException {
        Scanner in = new Scanner(new File("MONHOC.in"));
        int t = in.nextInt();
        ArrayList<MonHoc> lt = new ArrayList<>();
        in.nextLine();
        while(t-- >0){
            MonHoc mh = new MonHoc (in.nextLine(), in.nextLine(), Integer.parseInt(in.nextLine()));
            lt.add(mh);
        }
        Collections.sort(lt);
        for(MonHoc x : lt){
            System.out.println(x);
        }
        in.close();
    }
}
