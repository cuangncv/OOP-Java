public class Pair {
    private int dong, cot;

    public Pair (int dong, int cot){
        this.dong = dong;
        this.cot = cot;
    }

    @Override
    public String toString(){
        return "(" + dong + "," + cot + ")";
    }
}
