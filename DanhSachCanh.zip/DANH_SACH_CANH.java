import java.util.ArrayList;
import java.util.Scanner;

public class DANH_SACH_CANH {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int[][] a = new int[n + 1][n + 1];
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) a[i][j] = in.nextInt();
        }
        ArrayList<Pair> lt = new ArrayList<>();
        for (int i = 1; i <= n; i++) {
            for (int j = i+1; j <= n; j++) {
                if(a[i][j] == 1){
                    Pair pair = new Pair(i,j);
                    lt.add(pair);
                }
            }
        }
        for (Pair p : lt){
            System.out.println(p);
        }
    }
}
