public class MatHang implements Comparable<MatHang> {
    private String ma, ten, nhom;
    private double giamua, giaban, loinhuan;
    public MatHang(int i, String ten, String nhom, double giamua, double giaban){
       this.ma = "MH"+String.format("%02d",i);
       this.ten = ten;
       this.nhom = nhom;
       this.giamua = giamua;
       this.giaban = giaban;
       loinhuan = giaban - giamua;
    }

    @Override
    public String toString(){
        return ma + " " + ten + " " + nhom + " " + String.format("%.2f",loinhuan);
    }

    @Override
    public int compareTo(MatHang other){
        return Double.compare(other.loinhuan, this.loinhuan);
    }
}
