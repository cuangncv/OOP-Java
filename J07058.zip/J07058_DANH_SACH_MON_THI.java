import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J07058_DANH_SACH_MON_THI {
    public static void main(String[] args) throws IOException {
        ArrayList<MatHang> ds = new ArrayList<>();
        Scanner in = new Scanner(new File("MATHANG.in"));
        int n = Integer.parseInt(in.nextLine());
        for(int i = 1; i <= n; i++){
            ds.add(new MatHang( i, in.nextLine(), in.nextLine(), Double.parseDouble(in.nextLine()), Double.parseDouble(in.nextLine())));
        }
        Collections.sort(ds);
        for(MatHang tmp : ds){
            System.out.println(tmp);
        }
        in.close();
    }
}
