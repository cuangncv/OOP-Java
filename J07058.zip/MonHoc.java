public class MonHoc implements Comparable<MonHoc> {
    private String ma, ten, hinhthucthi;
    public MonHoc(String ma, String ten, String hinhthucthi){
       this.ma = ma;
       this.ten = ten;
       this.hinhthucthi = hinhthucthi;
    }

    @Override
    public String toString(){
        return ma + " " + ten + " " + hinhthucthi;
    }

    @Override
    public int compareTo(MonHoc other){
        return this.ma.compareTo(other.ma);
    }
}
