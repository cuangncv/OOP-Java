public class DonHang implements Comparable<DonHang> {
    private String ten, ma, stt;
    private double giamGia, tien;

    public DonHang (String ten, String ma, long donGia, long soLuong){
        this.ten = ten;
        this.ma = ma;
        this.stt = ma.substring(1,4);
        setGiamGia(donGia, soLuong);
        this.tien = donGia * soLuong - giamGia;
    }
    private void setGiamGia(long donGia, long soLuong){
        if(ma.substring(4).equals("1")) this.giamGia = donGia * soLuong * 0.5;
        else this.giamGia = donGia * soLuong * 0.3;
    }
    public int compareTo(DonHang other){
        return this.stt.compareTo(other.stt);
    }
    @Override
    public String toString(){
        return String.format("%s %s %s %.0f %.0f", ten, ma, stt, giamGia, tien);
    }
}